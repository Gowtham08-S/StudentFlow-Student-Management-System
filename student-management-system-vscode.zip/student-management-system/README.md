# StudentFlow — Student Management System

A complete CRUD web application for managing student enrolment records. The project pairs a Django REST Framework API with a responsive, fetch-powered frontend and SQLite for zero-install persistence.

## Features

- Create, read, update, and delete student records.
- Server-side and client-side validation for names, email, phone, course, and academic year.
- Search by student name, email, or course.
- Success and error toast notifications.
- Responsive dashboard layout for desktop, tablet, and mobile.
- Django admin at `/admin/` with the demo account `admin` / `admin123`.
- Postman collection, report, API reference, test evidence, and viva preparation.

## Quick start

```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py runserver
```

Open <http://127.0.0.1:8000/>. The database is created automatically as `backend/db.sqlite3` after migration. The `.env` file is intentionally excluded from Git; use `.env.example` as the template.

## API

- `GET/POST /api/students/`
- `GET/PUT/PATCH/DELETE /api/students/<id>/`
- Optional search: `/api/students/?search=computer`

See [`docs/API.md`](docs/API.md) for payloads and status codes. Import [`postman/Student-Management-System.postman_collection.json`](postman/Student-Management-System.postman_collection.json) into Postman.

## Project structure

```text
backend/    Django project, app, migrations, settings, SQLite database
frontend/   index.html, style.css, script.js
docs/       report, API reference, test results, viva Q&A
postman/    Postman collection with assertions
```

## Security and quality notes

Secrets are loaded from environment variables, the ORM is used exclusively, inputs are validated in both UI and serializer layers, and CORS is explicitly configured. For production, replace the demo secret, disable `DEBUG`, configure a real domain, and serve static assets through a production web server.
