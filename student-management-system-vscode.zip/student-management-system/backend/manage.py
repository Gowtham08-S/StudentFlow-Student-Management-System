#!/usr/bin/env python
"""Django command-line utility for administrative tasks."""
import os
import sys

def main():
    """Run administrative commands."""
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "student_api.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)

if __name__ == "__main__":
    main()
