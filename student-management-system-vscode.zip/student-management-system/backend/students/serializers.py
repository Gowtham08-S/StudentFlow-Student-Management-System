"""Validation and representation for Student API payloads."""
from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    """Serialize students and enforce business rules at the API boundary."""
    class Meta:
        model = Student
        fields = ["id", "name", "email", "phone", "course", "year", "created_at", "updated_at"]
        read_only_fields = ["id", "created_at", "updated_at"]

    def validate_name(self, value):
        """Require a meaningful non-blank name."""
        value = value.strip()
        if len(value) < 2:
            raise serializers.ValidationError("Name must contain at least 2 characters.")
        return value

    def validate_course(self, value):
        """Normalize and validate course text."""
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Course is required.")
        return value

    def validate(self, attrs):
        """Apply cross-field rules to the complete request."""
        if attrs.get("email", "").lower().endswith("@example.com"):
            raise serializers.ValidationError({"email": "Please use an institutional or personal email address."})
        if attrs.get("year", 1) > 4 and "course" in attrs and "phd" not in attrs["course"].lower():
            raise serializers.ValidationError({"year": "Years above 4 are reserved for PhD courses."})
        return attrs
