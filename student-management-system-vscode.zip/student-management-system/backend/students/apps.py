"""Students application configuration."""
from django.apps import AppConfig

class StudentsConfig(AppConfig):
    """Configure the students app."""
    default_auto_field = "django.db.models.BigAutoField"
    name = "students"
