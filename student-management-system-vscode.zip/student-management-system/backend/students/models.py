"""Database models for student records."""
from django.core.validators import MinValueValidator, MaxValueValidator, RegexValidator
from django.db import models

class Student(models.Model):
    """A student enrolled in a course."""
    name = models.CharField(max_length=120)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15, validators=[RegexValidator(r"^\+?[0-9]{10,15}$", "Enter a valid 10–15 digit phone number.")])
    course = models.CharField(max_length=120)
    year = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(6)])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["email"]), models.Index(fields=["course"])]

    def __str__(self):
        """Return a readable student label."""
        return f"{self.name} ({self.email})"
