"""REST API views for student CRUD operations."""
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import render
from .models import Student
from .serializers import StudentSerializer

class StudentListCreateView(generics.ListCreateAPIView):
    """List all students or create a new student."""
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    def get_queryset(self):
        """Support safe server-side search by name, email, or course."""
        queryset = super().get_queryset()
        search = self.request.query_params.get("search", "").strip()
        if search:
            from django.db.models import Q
            queryset = queryset.filter(Q(name__icontains=search) | Q(email__icontains=search) | Q(course__icontains=search))
        return queryset

class StudentDetailView(generics.RetrieveUpdateDestroyAPIView):
    """Retrieve, fully update, or delete one student."""
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

    def delete(self, request, *args, **kwargs):
        """Delete a student and return the standard empty response."""
        self.destroy(request, *args, **kwargs)
        return Response(status=status.HTTP_204_NO_CONTENT)

def frontend(request):
    """Render the single-page frontend when used outside the URL shortcut."""
    return render(request, "index.html")
