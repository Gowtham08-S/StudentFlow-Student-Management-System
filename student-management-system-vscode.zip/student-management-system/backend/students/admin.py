"""Admin registration for Student records."""
from django.contrib import admin
from .models import Student

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    """Provide useful list and search controls in admin."""
    list_display = ("id", "name", "email", "course", "year", "created_at")
    search_fields = ("name", "email", "course")
    list_filter = ("course", "year")
