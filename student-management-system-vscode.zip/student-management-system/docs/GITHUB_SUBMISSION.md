# GitHub Submission Guide

## Repository name

Recommended repository name: `student-management-system`

Recommended description: `Full-stack Student Management System with Django REST API, responsive frontend, SQLite database, validation, Postman tests, and project report.`

Live application: <https://studentflow-bwulvfuq.manus.space>

## Files that must be committed

The repository should contain the following items:

- `backend/` — Django project, Student app, migrations, settings, and requirements.
- `frontend/` — HTML, CSS, and JavaScript client.
- `docs/` — report, API reference, testing report, viva guide, final PDF, and screenshot evidence.
- `postman/` — Postman collection JSON export.
- `README.md` — setup and usage instructions.
- `LICENSE` — open-source license.
- `.gitignore` — rules excluding virtual environments, secrets, caches, and local database files.
- `backend/.env.example` — safe environment-variable template.

## Files that must not be committed

Never commit `backend/.env`, `backend/.venv/`, `backend/db.sqlite3`, `__pycache__/`, or `*.pyc`. The repository `.gitignore` already excludes these files. Do not include passwords, API keys, tokens, or personal credentials.

## Create the GitHub repository

1. Sign in to GitHub and select **New repository**.
2. Use the name `student-management-system`.
3. Add the description above.
4. Keep the repository empty: do not add a second README, license, or `.gitignore` because these files already exist locally.
5. Choose Public if the academic evaluator must access it directly.

## Push the prepared project

Replace `YOUR_USERNAME` with the GitHub account name:

```bash
cd student-management-system
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/student-management-system.git
git push -u origin main
```

If a remote already exists, use:

```bash
git remote set-url origin https://github.com/YOUR_USERNAME/student-management-system.git
git push -u origin main
```

GitHub may request a Personal Access Token instead of an account password. Use the token only at the authentication prompt; do not store it in project files.

## Final verification before submission

```bash
git status
git log --oneline --decorate -5
git ls-files
```

Confirm that `git status` is clean and that the output does not contain `.env`, `.venv`, `db.sqlite3`, `__pycache__`, or `.pyc` files.

## What to submit to the evaluator

Submit the GitHub repository URL, the live website URL, and the PDF report. Also provide the Postman collection from `postman/Student-Management-System.postman_collection.json` if the evaluator requests API evidence.

## Suggested repository topics

`django`, `django-rest-framework`, `student-management-system`, `crud`, `sqlite`, `javascript`, `responsive-design`, `postman`, `full-stack`, `python`
