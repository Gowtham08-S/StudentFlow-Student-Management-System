# Student Management System — Project Report

## 1. Introduction

StudentFlow is a browser-based student record management system. It replaces scattered spreadsheets or paper registers with a simple, searchable, validated CRUD interface backed by a REST API.

## 2. Problem statement

Academic staff need a dependable way to store student identity, contact, course, and year information. Manual records create duplicate entries, inconsistent formats, slow searching, and avoidable update errors.

## 3. Objectives and users

The objective is to provide a clean end-to-end workflow for adding, viewing, editing, searching, and deleting students. Primary users are administrators, academic coordinators, and office staff.

## 4. Scope and requirements

The system stores `id`, `name`, `email`, `phone`, `course`, `year`, `created_at`, and `updated_at`. It provides REST endpoints, a responsive HTML/CSS/JavaScript frontend, validation, CORS support, SQLite persistence, Postman tests, and documentation.

## 5. Technology stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, vanilla JavaScript, Fetch API |
| Backend | Python, Django 5, Django REST Framework |
| Database | SQLite |
| Testing | curl, Django checks, Postman collection |
| Version control | Git |

## 6. System architecture

The browser sends JSON requests through the Fetch API to DRF class-based views. Serializers validate incoming data, Django ORM persists the Student model in SQLite, and JSON responses update the table and summary cards.

## 7. Database design

`Student.id` is the auto-incrementing primary key. `email` is unique and indexed. `phone` is constrained to 10–15 digits with an optional plus sign. `year` is constrained to 1–6. Timestamps are managed by Django.

## 8. Frontend development

The interface uses a sidebar, summary cards, searchable table, modal form, responsive breakpoints, semantic labels, keyboard escape handling, and clear empty/loading states. The UI is intentionally lightweight and requires no frontend build step.

## 9. Backend development

`ListCreateAPIView` handles collection operations and `RetrieveUpdateDestroyAPIView` handles individual records. The serializer contains field-level and object-level rules. Search is performed with ORM `icontains` filters across three fields.

## 10. REST API and integration

The frontend uses JSON requests with `GET`, `POST`, `PUT`, and `DELETE`. It renders server errors as toast messages and refreshes the list after successful mutations. CORS settings are explicit and environment-driven.

## 11. Validation and exception handling

Required fields, minimum name length, email format, unique email, phone format, course presence, year range, and a PhD rule are enforced. DRF returns structured HTTP 400 responses for invalid input; the frontend aggregates those messages for the user.

## 12. Security

The secret key is loaded from `.env` and `.env` is ignored by Git. Database access uses Django ORM only. Production guidance includes disabling debug, restricting hosts, rotating secrets, and using HTTPS.

## 13. Testing

The project was tested with Django migrations, Django system checks, endpoint requests, validation failures, search behavior, frontend asset loading, and Git/package inspection. Full test evidence is in [`TESTING.md`](TESTING.md).

## 14. Conclusion and future enhancements

StudentFlow meets the CRUD brief and provides a clear submission artifact. Future improvements could include authentication roles, pagination, CSV export, course reference tables, automated unit tests, and deployment behind a production WSGI server.
