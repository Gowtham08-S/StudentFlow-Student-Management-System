# Testing and Results

Testing was performed against the local Django server at `http://127.0.0.1:8000`.

| ID | Test case | Expected | Result |
|---|---|---|---|
| T01 | `python manage.py check` | No configuration errors | Pass |
| T02 | `POST /api/students/` with valid body | 201 and JSON record | Pass |
| T03 | `GET /api/students/` | 200 and list | Pass |
| T04 | `GET /api/students/1/` | 200 and single record | Pass |
| T05 | `PUT /api/students/1/` | 200 and updated fields | Pass |
| T06 | `DELETE /api/students/1/` | 204 empty response | Pass |
| T07 | Empty email | 400 validation response | Pass |
| T08 | Invalid phone | 400 validation response | Pass |
| T09 | Duplicate email | 400 unique constraint response | Pass |
| T10 | Search by name/course | Filtered 200 list | Pass |
| T11 | Browser desktop layout | Table, form, toasts visible | Pass |
| T12 | Browser mobile layout | Sidebar collapses and form stacks | Pass |

## Re-run commands

```bash
cd backend && source .venv/bin/activate
python manage.py check
python manage.py runserver
```

Then import the Postman collection or use the `curl` examples in the project submission notes. Tests are intentionally independent of a third-party service.
