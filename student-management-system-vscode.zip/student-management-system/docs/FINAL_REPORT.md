# StudentFlow — Student Management System

## 1. Title and Project Overview

**Project title:** StudentFlow — Student Management System  
**Project type:** Full-stack CRUD web application  
**Live deployment:** [studentflow-bwulvfuq.manus.space](https://studentflow-bwulvfuq.manus.space)

StudentFlow is a web application for maintaining student enrolment records. It provides a responsive dashboard where authorized users can add, view, search, edit, and delete student information. The application combines a React frontend, a managed TypeScript server, a tRPC API, and a managed MySQL-compatible database.

## 2. Problem Statement

Educational institutions often maintain student records in spreadsheets or paper registers. These approaches make searching slow, allow inconsistent data formats, and increase the risk of duplicate or outdated records. Staff need a central interface that validates information and supports reliable create, read, update, and delete operations.

StudentFlow addresses this problem by providing a searchable directory with structured fields, server-side validation, database persistence, and immediate success or error feedback.

## 3. Objectives

The project objectives were to create a complete student CRUD system, reduce manual record-management effort, validate all important input fields, provide a responsive interface for desktop and mobile devices, and expose a maintainable API for future integrations. A further objective was to deploy the application on permanent managed hosting rather than a temporary development server.

## 4. Technology Stack

| Layer | Technology | Purpose |
|---|---|---|
| Frontend | React 19, TypeScript | Component-based user interface |
| Styling | Tailwind CSS and custom CSS | Responsive visual design |
| API | tRPC 11 | Type-safe client-server procedures |
| Backend | Node.js and Express | Managed server runtime |
| Database | MySQL-compatible managed database | Persistent student records |
| ORM | Drizzle ORM | Typed database queries and migrations |
| Validation | Zod | Input and business-rule validation |
| Testing | Vitest and TypeScript compiler | Automated verification |
| Hosting | Manus WebDev managed hosting | Permanent HTTPS deployment |

## 5. System Architecture

The browser renders the React dashboard and invokes typed tRPC procedures. The server validates each request using Zod, calls database helper functions, and returns typed results. Drizzle ORM converts those operations into SQL for the managed database. The deployed site is served through managed HTTPS hosting.

```mermaid
flowchart LR
  U[User] --> UI[React StudentFlow Dashboard]
  UI --> API[tRPC API Procedures]
  API --> V[Zod Validation]
  V --> DBH[Database Helpers]
  DBH --> ORM[Drizzle ORM]
  ORM --> DB[(Managed MySQL Database)]
```

## 6. Database and ER Diagram

The main entity is `Student`. Each student has a generated primary key and a unique email address. Timestamps are generated and maintained by the database. The template also contains a `users` table for managed authentication compatibility.

```mermaid
erDiagram
  STUDENT {
    int id PK
    varchar name
    varchar email UK
    varchar phone
    varchar course
    int year
    timestamp createdAt
    timestamp updatedAt
  }
  USER {
    int id PK
    varchar openId UK
    varchar name
    varchar email
    varchar role
    timestamp createdAt
    timestamp updatedAt
  }
```

| Field | Type | Constraint | Description |
|---|---|---|---|
| id | Integer | Primary key, auto-increment | Unique student identifier |
| name | VARCHAR(120) | Required | Student full name |
| email | VARCHAR(320) | Required, unique | Student email address |
| phone | VARCHAR(15) | Required, validated | 10–15 digit phone number |
| course | VARCHAR(120) | Required | Academic course |
| year | Integer | Required, 1–6 | Academic year |
| createdAt | Timestamp | Automatic | Record creation time |
| updatedAt | Timestamp | Automatic | Last modification time |

## 7. UI Screenshots

The dashboard uses a dark navigation rail, summary cards, a searchable student table, modal forms, responsive breakpoints, and toast notifications. The current deployed interface is shown below.

![StudentFlow dashboard](assets/studentflow-dashboard.png)

**Figure 1.** StudentFlow dashboard in the managed preview. The empty state is displayed before the first record is created. The same screen changes to a data table after a successful create operation.

## 8. API Endpoint Documentation

The deployed application uses tRPC procedures rather than manually duplicated REST handlers. The logical API operations are listed below.

| Procedure | Input | Result | Purpose |
|---|---|---|---|
| `students.list` | Optional `search` string | Student array | List all students or filter by name, email, or course |
| `students.get` | Student `id` | One student or undefined | Retrieve a single record |
| `students.create` | name, email, phone, course, year | Created student | Add a new record |
| `students.update` | Student `id` plus validated data | Updated student | Modify an existing record |
| `students.delete` | Student `id` | Success object | Remove a record |

Validation failures return typed procedure errors. The email must be valid and unique. The phone must contain 10–15 digits with an optional plus sign. The year must be between 1 and 6. Years above 4 require a course name containing “PhD”.

## 9. CRUD Implementation Details

**Create:** The modal form collects the five editable fields. The client performs a completeness check, then calls `students.create`. The server applies the Zod schema before inserting the record.

**Read:** The dashboard calls `students.list` on load and whenever the search text changes. The server applies case-insensitive matching to name, email, and course.

**Update:** Selecting the pencil icon loads the existing record into the same modal. The update procedure receives the record identifier and a complete validated data object.

**Delete:** Selecting the trash icon requests confirmation before calling `students.delete`. The table is invalidated after success so the deleted item disappears immediately.

## 10. Testing Results

| Test | Expected result | Result |
|---|---|---|
| Valid student validation | Accepted | Pass |
| Invalid name, email, phone, course, and year | Rejected with field errors | Pass |
| Academic year above 4 without PhD course | Rejected | Pass |
| Auth logout regression test | Session cookie cleared | Pass |
| TypeScript compilation | No type errors | Pass |
| Production build | Vite and server bundle complete | Pass |
| Empty dashboard state | Helpful call-to-action shown | Pass |
| Responsive layout | Sidebar, cards, and form adapt to viewport | Pass |

Automated verification completed with **2 test files and 4 passing tests**. The production build completed successfully and the deployed preview loaded without runtime errors.

## 11. Installation and Execution Steps

The permanent deployment can be opened at [studentflow-bwulvfuq.manus.space](https://studentflow-bwulvfuq.manus.space). For local development, use the managed project repository:

```bash
git clone <repository-reference>
cd studentflow-permanent
pnpm install
pnpm dev
```

To verify the project locally:

```bash
pnpm check
pnpm test
pnpm build
```

Database changes are managed through Drizzle migrations:

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

## 12. Challenges and Solutions

The original application used Django, DRF, and SQLite in a temporary sandbox. That implementation was useful for local submission testing but was not suitable for a permanent managed deployment in this environment. The solution was to migrate the functionality to the available managed WebDev runtime while preserving the user-facing design and CRUD behavior.

A second challenge was maintaining validation across layers. The solution was to centralize the rules in a reusable Zod schema and cover the important cases with Vitest tests. A third challenge was ensuring that database changes remained reproducible. The solution was to define the schema in Drizzle, generate a migration, review the SQL, and apply it to the managed database.

## 13. Future Enhancements

Future versions could add role-based permissions, CSV import and export, pagination for large directories, course reference data, audit logs, dashboard analytics, bulk deletion with stronger safeguards, and automated end-to-end browser tests. A custom domain and institution branding could also be added for production use.

## 14. Git Repository and Reference Details

The managed project is maintained in Git with the following recent references:

| Reference | Description |
|---|---|
| `d181730` | Completed managed StudentFlow migration with database-backed CRUD, responsive UI, validation, and tests |
| `5d8f6e8` | Initial managed WebDev project bootstrap |

The original local submission package is available as `student-management-system.zip`. The permanent managed project is named `studentflow-permanent` and is checkpointed for deployment as version `d1817308`.

## Conclusion

StudentFlow meets the requirements of a complete student-management CRUD application. It provides a clear user interface, typed API procedures, persistent storage, validation, testing evidence, documentation, and permanent managed hosting.

## References

[1]: https://react.dev/ "React Documentation"
[2]: https://orm.drizzle.team/docs/overview "Drizzle ORM Documentation"
[3]: https://zod.dev/ "Zod Documentation"
[4]: https://vitest.dev/ "Vitest Documentation"
[5]: https://trpc.io/docs "tRPC Documentation"
