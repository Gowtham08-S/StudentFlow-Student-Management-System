# API Reference

Base URL: `http://127.0.0.1:8000`

| Method | Endpoint | Purpose | Success |
|---|---|---|---|
| GET | `/api/students/` | List students; optional `?search=` | 200 |
| POST | `/api/students/` | Create a student | 201 |
| GET | `/api/students/<id>/` | Fetch one student | 200 |
| PUT | `/api/students/<id>/` | Replace one student | 200 |
| PATCH | `/api/students/<id>/` | Partially update one student | 200 |
| DELETE | `/api/students/<id>/` | Delete one student | 204 |

## Create/update body

```json
{"name":"Aisha Khan","email":"aisha@university.edu","phone":"+919876543210","course":"Computer Science","year":2}
```

The response adds `id`, `created_at`, and `updated_at`. Invalid fields return `400 Bad Request` with field-keyed JSON messages. A duplicate email returns `400`. A missing ID returns `404`.
