const API_URL = '/api/students/';
let students = [];
const $ = (id) => document.getElementById(id);

async function loadStudents() {
  const search = $('searchInput').value.trim();
  try {
    const response = await fetch(`${API_URL}${search ? `?search=${encodeURIComponent(search)}` : ''}`);
    if (!response.ok) throw new Error('Could not load student records.');
    students = await response.json();
    renderStudents();
  } catch (error) { showToast(error.message, true); }
}
function renderStudents() {
  const body = $('studentTable'); const empty = $('emptyState');
  $('totalCount').textContent = students.length;
  $('courseCount').textContent = new Set(students.map((s) => s.course)).size;
  $('latestDate').textContent = students[0] ? formatDate(students[0].created_at) : '—';
  $('recordCount').textContent = `${students.length} record${students.length === 1 ? '' : 's'}`;
  if (!students.length) { body.innerHTML = ''; empty.hidden = false; return; }
  empty.hidden = true;
  body.innerHTML = students.map((student) => `<tr><td><div class="student-name">${escapeHtml(student.name)}</div><div class="student-id">ID ${student.id}</div></td><td><div class="contact">${escapeHtml(student.email)}</div><div class="contact">${escapeHtml(student.phone)}</div></td><td><span class="course-pill">${escapeHtml(student.course)}</span></td><td><span class="year-badge">Year ${student.year}</span></td><td><span class="updated">${formatDate(student.updated_at)}</span></td><td class="actions"><button class="icon-btn" title="Edit student" onclick="openEdit(${student.id})">✎</button><button class="icon-btn delete-btn" title="Delete student" onclick="deleteStudent(${student.id})">⌫</button></td></tr>`).join('');
}
function escapeHtml(value) { const div = document.createElement('div'); div.textContent = value; return div.innerHTML; }
function formatDate(value) { return new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(value)); }
function openModal(student = null) { $('modalBackdrop').hidden = false; $('modalTitle').textContent = student ? 'Edit student' : 'Add a student'; $('saveBtn').textContent = student ? 'Update student' : 'Save student'; $('studentId').value = student?.id || ''; ['name','email','phone','course'].forEach((field) => { $(field).value = student?.[field] || ''; }); $('year').value = student?.year || ''; $('name').focus(); }
function closeModal() { $('modalBackdrop').hidden = true; $('studentForm').reset(); }
async function saveStudent(event) { event.preventDefault(); const id = $('studentId').value; const payload = { name: $('name').value.trim(), email: $('email').value.trim(), phone: $('phone').value.replace(/\s/g, ''), course: $('course').value.trim(), year: Number($('year').value) }; if (!payload.name || !payload.email || !payload.phone || !payload.course || !payload.year) return showToast('Please complete every field.', true); try { const response = await fetch(id ? `${API_URL}${id}/` : API_URL, { method: id ? 'PUT' : 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) }); const data = await response.json(); if (!response.ok) throw new Error(Object.values(data).flat().join(' ')); closeModal(); showToast(id ? 'Student updated successfully.' : 'Student added successfully.'); await loadStudents(); } catch (error) { showToast(error.message, true); } }
window.openEdit = (id) => openModal(students.find((student) => student.id === id));
window.deleteStudent = async (id) => { if (!window.confirm('Delete this student record?')) return; try { const response = await fetch(`${API_URL}${id}/`, { method: 'DELETE' }); if (!response.ok) throw new Error('Delete failed.'); showToast('Student deleted.'); await loadStudents(); } catch (error) { showToast(error.message, true); } };
function showToast(message, isError = false) { const toast = document.createElement('div'); toast.className = `toast${isError ? ' error' : ''}`; toast.textContent = message; $('toastContainer').appendChild(toast); setTimeout(() => toast.remove(), 3600); }
$('studentForm').addEventListener('submit', saveStudent); $('addStudentBtn').addEventListener('click', () => openModal()); $('emptyAddBtn').addEventListener('click', () => openModal()); $('closeModal').addEventListener('click', closeModal); $('cancelBtn').addEventListener('click', closeModal); $('modalBackdrop').addEventListener('click', (event) => { if (event.target === $('modalBackdrop')) closeModal(); }); $('searchInput').addEventListener('input', loadStudents); document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModal(); }); loadStudents();
